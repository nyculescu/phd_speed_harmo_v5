#!/bin/bash
# V302: rule grid and B with the shared reward, then C at safety weights 20 and 40, then evaluation; frozen code b7c535a.
set -e
cd /home/catalin/work/phd/v5b1_runs/b_train/code_b7c535a
export PYTHONPATH=/home/catalin/work/phd/v5b1_runs/b_train/code_b7c535a OMP_NUM_THREADS=1
unset SUMO_HOME
P="/home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet"
pids=()
$P.b_train matrix --out /home/catalin/work/phd/v5b1_runs/b_train/night/c8/grid --spec /home/catalin/work/phd/v5b1_runs/b_train/night/c8/grid_spec.json --workers 16 &
pids+=($!)
for L in 0 1 2; do
  $P.b_train train --cfg 8 --out /home/catalin/work/phd/v5b1_runs/b_train/night/c8/trainB --learner $L --updates 500 --n-envs 3 &
  pids+=($!)
done
for p in "${pids[@]}"; do wait $p; done
/home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python /srv/shared/Workspace/phd/phd_speed_harmo_v5b1/docs/research/results/b_c8_select.py /home/catalin/work/phd/v5b1_runs/b_train/night/c8/grid/rows.jsonl /home/catalin/work/phd/v5b1_runs/b_train/night/c8/select.json
pids=()
for L in 0 1 2; do
  $P.c_train train --out /home/catalin/work/phd/v5b1_runs/b_train/night/c8/trainG --learner $L --updates 250 --n-envs 3 --env '{"w_flow": 0.4, "w_safety": 20.0}' &
  pids+=($!)
  $P.c_train train --out /home/catalin/work/phd/v5b1_runs/b_train/night/c8/trainH --learner $L --updates 250 --n-envs 3 --env '{"w_flow": 0.4, "w_safety": 40.0}' &
  pids+=($!)
done
for p in "${pids[@]}"; do wait $p; done
/home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python /home/catalin/work/phd/v5b1_runs/b_train/night/c8/mkeval.py
$P.b_train matrix --out /home/catalin/work/phd/v5b1_runs/b_train/night/c8/eval --spec /home/catalin/work/phd/v5b1_runs/b_train/night/c8/eval_spec.json --workers 16
