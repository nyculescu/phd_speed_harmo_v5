#!/bin/bash
# V269 run 3: learners 1 and 2, then, once learner 0 has finished too, the fixed offsets and validation.
cd /home/catalin/work/phd/v5b1_runs/b_train/code_2863282
export PYTHONPATH=/home/catalin/work/phd/v5b1_runs/b_train/code_2863282 OMP_NUM_THREADS=1
unset SUMO_HOME
pids=()
for L in 1 2; do
  /home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet.b_train train --cfg 3 --out /home/catalin/work/phd/v5b1_runs/b_train/run3 --learner $L --updates 500 --n-envs 8 &
  pids+=($!)
done
rc=0
for p in "${pids[@]}"; do wait $p || rc=1; done
[ $rc -eq 0 ] || exit 1
while systemctl --user is-active -q b-run3-47076bb.service; do sleep 30; done
[ -f /home/catalin/work/phd/v5b1_runs/b_train/run3/L0_final.zip ] || exit 1
/home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet.b_train sweep --cfg 3 --out /home/catalin/work/phd/v5b1_runs/b_train/run3 --seeds 20 --workers 24 || exit 1
for L in 0 1 2; do
  /home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet.b_train eval --cfg 3 --out /home/catalin/work/phd/v5b1_runs/b_train/run3 --model /home/catalin/work/phd/v5b1_runs/b_train/run3/L${L}_final --seeds 20 --workers 24 || exit 1
done
