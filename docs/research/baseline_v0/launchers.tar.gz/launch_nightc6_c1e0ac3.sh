#!/bin/bash
# V294: first C run with the per-vehicle reward in training (flow 0.4, safety 10); stops by 06:00; frozen code c1e0ac3.
cd /home/catalin/work/phd/v5b1_runs/b_train/code_c1e0ac3
export PYTHONPATH=/home/catalin/work/phd/v5b1_runs/b_train/code_c1e0ac3 OMP_NUM_THREADS=1
unset SUMO_HOME
P="/home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet"
pids=()
for L in 0 1 2; do
  $P.c_train train --out /home/catalin/work/phd/v5b1_runs/b_train/night/c/train6 --learner $L --updates 500 --n-envs 3 --env '{"w_flow": 0.4, "w_safety": 10.0}' &
  pids+=($!)
done
sleep $(( $(date -d 06:00 +%s) - $(date +%s) ))
kill "${pids[@]}"
pkill -f "phd_speed_harmo_v5b1_toolchain/venv/bin/python -c from multiprocessing.spawn" || true
