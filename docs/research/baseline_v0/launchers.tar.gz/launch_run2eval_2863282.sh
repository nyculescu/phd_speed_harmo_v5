#!/bin/bash
# V270 run 2 validation only (training finished; the first attempt crashed on a code bug before any evaluation).
cd /home/catalin/work/phd/v5b1_runs/b_train/code_2863282
export PYTHONPATH=/home/catalin/work/phd/v5b1_runs/b_train/code_2863282 OMP_NUM_THREADS=1
unset SUMO_HOME
for L in 0 1 2; do
  /home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet.b_train eval --cfg 2 --out /home/catalin/work/phd/v5b1_runs/b_train/run2 --model /home/catalin/work/phd/v5b1_runs/b_train/run2/L${L}_final --seeds 20 --workers 8 || exit 1
done
