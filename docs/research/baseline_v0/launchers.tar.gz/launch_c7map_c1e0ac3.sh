#!/bin/bash
# V299: F0-F2 on the p303 robustness conditions; frozen code c1e0ac3.
set -e
cd /home/catalin/work/phd/v5b1_runs/b_train/code_c1e0ac3
export PYTHONPATH=/home/catalin/work/phd/v5b1_runs/b_train/code_c1e0ac3 OMP_NUM_THREADS=1
unset SUMO_HOME
/home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet.b_train matrix --out /home/catalin/work/phd/v5b1_runs/b_train/night/c/robustF --spec /home/catalin/work/phd/v5b1_runs/b_train/night/c/robustF_spec.json --workers 16
