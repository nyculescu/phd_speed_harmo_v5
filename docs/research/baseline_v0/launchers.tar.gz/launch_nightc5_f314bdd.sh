#!/bin/bash
# V293: clock without the flow reward, safety 10; frozen code f314bdd.
set -e
cd /home/catalin/work/phd/v5b1_runs/b_train/code_f314bdd
export PYTHONPATH=/home/catalin/work/phd/v5b1_runs/b_train/code_f314bdd OMP_NUM_THREADS=1
unset SUMO_HOME
P="/home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet"
pids=()
for L in 0 1 2; do
  $P.c_train train --out /home/catalin/work/phd/v5b1_runs/b_train/night/c/train5 --learner $L --updates 170 --n-envs 3 --env '{"w_flow": 0.0, "w_safety": 10.0}' &
  pids+=($!)
done
for p in "${pids[@]}"; do wait $p; done
