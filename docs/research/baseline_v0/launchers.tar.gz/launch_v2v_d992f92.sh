#!/bin/bash
# V275 V2V-conditional headway sweep from frozen code d992f92.
cd /home/catalin/work/phd/v5b1_runs/b_train/code_d992f92
export PYTHONPATH=/home/catalin/work/phd/v5b1_runs/b_train/code_d992f92 OMP_NUM_THREADS=1
unset SUMO_HOME
/home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet.b_train v2v --out /home/catalin/work/phd/v5b1_runs/b_train/v2v1 --seeds 20 --workers 27
