#!/bin/bash
# V290: C run 3 (3 learners x 3 envs); frozen code 3aa49fc.
set -e
cd /home/catalin/work/phd/v5b1_runs/b_train/code_3aa49fc
export PYTHONPATH=/home/catalin/work/phd/v5b1_runs/b_train/code_3aa49fc OMP_NUM_THREADS=1
unset SUMO_HOME
P="/home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet"
pids=()
for L in 0 1 2; do
  $P.c_train train --out /home/catalin/work/phd/v5b1_runs/b_train/night/c/train3 --learner $L --updates 250 --n-envs 3 &
  pids+=($!)
done
for p in "${pids[@]}"; do wait $p; done
