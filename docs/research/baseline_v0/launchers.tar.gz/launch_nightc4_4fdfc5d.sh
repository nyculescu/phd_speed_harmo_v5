#!/bin/bash
# V292: C run 4, from run 3's final policies, safety weight 20; frozen code 4fdfc5d.
set -e
cd /home/catalin/work/phd/v5b1_runs/b_train/code_4fdfc5d
export PYTHONPATH=/home/catalin/work/phd/v5b1_runs/b_train/code_4fdfc5d OMP_NUM_THREADS=1
unset SUMO_HOME
P="/home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet"
pids=()
for L in 0 1 2; do
  $P.c_train train --out /home/catalin/work/phd/v5b1_runs/b_train/night/c/train4 --learner $L --updates 200 --n-envs 3 --resume /home/catalin/work/phd/v5b1_runs/b_train/night/c/train3/C${L}_final.pt &
  pids+=($!)
done
for p in "${pids[@]}"; do wait $p; done
