#!/bin/bash
# V283: rule tuning, run 5 training (3 learners x 3 envs), validation; frozen code 539b65e; 9 workers.
set -e
cd /home/catalin/work/phd/v5b1_runs/b_train/code_539b65e
export PYTHONPATH=/home/catalin/work/phd/v5b1_runs/b_train/code_539b65e OMP_NUM_THREADS=1
unset SUMO_HOME
P="/home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet.b_train"
$P matrix --out /home/catalin/work/phd/v5b1_runs/b_train/night/rule2 --spec /home/catalin/work/phd/v5b1_runs/b_train/night/rule2_spec.json --workers 9
pids=()
for L in 0 1 2; do
  $P train --cfg 7 --out /home/catalin/work/phd/v5b1_runs/b_train/night/run5b --learner $L --updates 500 --n-envs 3 &
  pids+=($!)
done
for p in "${pids[@]}"; do wait $p; done
$P matrix --out /home/catalin/work/phd/v5b1_runs/b_train/night/val5b --spec /home/catalin/work/phd/v5b1_runs/b_train/night/val5b_spec.json --workers 9
