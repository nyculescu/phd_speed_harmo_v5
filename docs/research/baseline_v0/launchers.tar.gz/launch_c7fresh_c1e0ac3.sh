#!/bin/bash
# V297: fresh-seed check of C policies F0-F2 and the missing opponents; frozen code c1e0ac3.
set -e
cd /home/catalin/work/phd/v5b1_runs/b_train/code_c1e0ac3
export PYTHONPATH=/home/catalin/work/phd/v5b1_runs/b_train/code_c1e0ac3 OMP_NUM_THREADS=1
unset SUMO_HOME
/home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet.b_train matrix --out /home/catalin/work/phd/v5b1_runs/b_train/night/c/freshF --spec /home/catalin/work/phd/v5b1_runs/b_train/night/c/freshF_spec.json --workers 16
