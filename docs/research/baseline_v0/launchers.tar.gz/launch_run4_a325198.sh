#!/bin/bash
# V277 run 4 from frozen code a325198: fixed zone opponents alongside 3 learners x 6 envs, then validation with and without delay.
cd /home/catalin/work/phd/v5b1_runs/b_train/code_a325198
export PYTHONPATH=/home/catalin/work/phd/v5b1_runs/b_train/code_a325198 OMP_NUM_THREADS=1
unset SUMO_HOME
pids=()
/home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet.b_train zones --cfg 6 --out /home/catalin/work/phd/v5b1_runs/b_train/run4 --seeds 20 --workers 9 &
pids+=($!)
for L in 0 1 2; do
  /home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet.b_train train --cfg 6 --out /home/catalin/work/phd/v5b1_runs/b_train/run4 --learner $L --updates 500 --n-envs 6 &
  pids+=($!)
done
rc=0
for p in "${pids[@]}"; do wait $p || rc=1; done
[ $rc -eq 0 ] || exit 1
for L in 0 1 2; do
  /home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet.b_train eval --cfg 6 --out /home/catalin/work/phd/v5b1_runs/b_train/run4 --model /home/catalin/work/phd/v5b1_runs/b_train/run4/L${L}_final --seeds 20 --workers 27 || exit 1
  /home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet.b_train eval --cfg 6 --asl 0.5 --out /home/catalin/work/phd/v5b1_runs/b_train/run4 --model /home/catalin/work/phd/v5b1_runs/b_train/run4/L${L}_final --seeds 20 --workers 27 || exit 1
done
