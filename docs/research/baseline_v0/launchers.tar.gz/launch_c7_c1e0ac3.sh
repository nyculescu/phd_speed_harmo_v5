#!/bin/bash
# V296: C with the intended reward, 250 updates, then validation; frozen code c1e0ac3.
set -e
cd /home/catalin/work/phd/v5b1_runs/b_train/code_c1e0ac3
export PYTHONPATH=/home/catalin/work/phd/v5b1_runs/b_train/code_c1e0ac3 OMP_NUM_THREADS=1
unset SUMO_HOME
P="/home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet"
pids=()
for L in 0 1 2; do
  $P.c_train train --out /home/catalin/work/phd/v5b1_runs/b_train/night/c/train7 --learner $L --updates 250 --n-envs 3 --env '{"w_flow": 0.4, "w_safety": 10.0}' &
  pids+=($!)
done
for p in "${pids[@]}"; do wait $p; done
$P.b_train matrix --out /home/catalin/work/phd/v5b1_runs/b_train/night/c/valF --spec /home/catalin/work/phd/v5b1_runs/b_train/night/c/valF_spec.json --workers 9
