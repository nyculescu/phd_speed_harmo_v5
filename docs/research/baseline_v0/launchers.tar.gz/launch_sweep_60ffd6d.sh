#!/bin/bash
# Whole-network check of the 30 km/h constant cap from frozen code 60ffd6d.
cd /home/catalin/work/phd/v5b1_runs/b_train/code_60ffd6d
export PYTHONPATH=/home/catalin/work/phd/v5b1_runs/b_train/code_60ffd6d OMP_NUM_THREADS=1
unset SUMO_HOME
/home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet.b_train sweep --out /home/catalin/work/phd/v5b1_runs/b_train/sweep2 --seeds 20 --workers 24 --offsets 5
