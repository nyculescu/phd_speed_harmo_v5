import json
L=[4600,5300]; te=list(range(7419650,7419670))
C={"cav":True,"decision":5.0,"alks_asl":0.5,"ref_delay":True}
Z={"zones":True,"decision":10.0,"alks_asl":0.5,"w_change":0.1,"ref_delay":True}
R="/home/catalin/work/phd/v5b1_runs/b_train/night"
s=[]
for t,d,x in (("F","c/train7","C"),("G","c8/trainG","C"),("H","c8/trainH","C")):
    s+=[{"name":f"{t}{i}","model":{"pt":f"{R}/{d}/C{i}_final.pt"},"kw":C,"levels":L,"seeds":te} for i in range(3)]
s+=[{"name":f"B{i}","model":f"{R}/c8/trainB/L{i}_final","kw":{**Z,"shared_reward":True},"levels":L,"seeds":te} for i in range(3)]
sel=json.load(open("/home/catalin/work/phd/v5b1_runs/b_train/night/c8/select.json"))
rules=sorted({n for v in sel.values() for n in v["front"]}|{"p303"})
s+=[{"name":n,"model":{"cav_rule":[int(c) for c in n[1:]]},"kw":C,"levels":L,"seeds":te} for n in rules]
s+=[{"name":"a000","model":[0,0,0],"kw":Z,"levels":L,"seeds":te},{"name":"a333","model":[3,3,3],"kw":Z,"levels":L,"seeds":te},{"name":"r2_0.8_02","model":{"level":2,"on":0.8,"zones":[0,2]},"kw":Z,"levels":L,"seeds":te}]
json.dump(s,open("/home/catalin/work/phd/v5b1_runs/b_train/night/c8/eval_spec.json","w")); print(len(s),rules)
