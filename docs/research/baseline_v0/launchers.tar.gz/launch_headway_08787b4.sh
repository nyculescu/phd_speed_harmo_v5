#!/bin/bash
# V273 fixed-headway sweep from frozen code 08787b4.
cd /home/catalin/work/phd/v5b1_runs/b_train/code_08787b4
export PYTHONPATH=/home/catalin/work/phd/v5b1_runs/b_train/code_08787b4 OMP_NUM_THREADS=1
unset SUMO_HOME
/home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet.b_train headway --out /home/catalin/work/phd/v5b1_runs/b_train/headway1 --seeds 20 --workers 27
