#!/bin/bash
# V265 first B training run from frozen code 4b146b0: 3 learners x 8 envs, then validation against no control.
cd /home/catalin/work/phd/v5b1_runs/b_train/code_4b146b0
export PYTHONPATH=/home/catalin/work/phd/v5b1_runs/b_train/code_4b146b0 OMP_NUM_THREADS=1
unset SUMO_HOME
pids=()
for L in 0 1 2; do
  /home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet.b_train train --out /home/catalin/work/phd/v5b1_runs/b_train/run1 --learner $L --updates 500 --n-envs 8 &
  pids+=($!)
done
rc=0
for p in "${pids[@]}"; do wait $p || rc=1; done
[ $rc -eq 0 ] || exit 1
for L in 0 1 2; do
  /home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet.b_train eval --out /home/catalin/work/phd/v5b1_runs/b_train/run1 --model /home/catalin/work/phd/v5b1_runs/b_train/run1/L${L}_final --seeds 20 --workers 24 || exit 1
done
