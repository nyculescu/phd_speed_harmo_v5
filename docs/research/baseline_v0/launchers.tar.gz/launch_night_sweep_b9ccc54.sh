#!/bin/bash
# V281 fixed headway sweep with delay, from frozen code b9ccc54.
cd /home/catalin/work/phd/v5b1_runs/b_train/code_b9ccc54
export PYTHONPATH=/home/catalin/work/phd/v5b1_runs/b_train/code_b9ccc54 OMP_NUM_THREADS=1
unset SUMO_HOME
exec /home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet.b_train matrix --out /home/catalin/work/phd/v5b1_runs/b_train/night/sweep --spec /home/catalin/work/phd/v5b1_runs/b_train/night/sweep_spec.json --workers 9
