#!/bin/bash
# V267 run 2 from frozen code 7b01783: fixed offsets as the opponent, then 3 learners x 8 envs, then validation.
cd /home/catalin/work/phd/v5b1_runs/b_train/code_7b01783
export PYTHONPATH=/home/catalin/work/phd/v5b1_runs/b_train/code_7b01783 OMP_NUM_THREADS=1
unset SUMO_HOME
/home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet.b_train sweep --run2 --out /home/catalin/work/phd/v5b1_runs/b_train/run2 --seeds 20 --workers 24 || exit 1
pids=()
for L in 0 1 2; do
  /home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet.b_train train --run2 --out /home/catalin/work/phd/v5b1_runs/b_train/run2 --learner $L --updates 500 --n-envs 8 &
  pids+=($!)
done
rc=0
for p in "${pids[@]}"; do wait $p || rc=1; done
[ $rc -eq 0 ] || exit 1
for L in 0 1 2; do
  /home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet.b_train eval --run2 --out /home/catalin/work/phd/v5b1_runs/b_train/run2 --model /home/catalin/work/phd/v5b1_runs/b_train/run2/L${L}_final --seeds 20 --workers 24 || exit 1
done
