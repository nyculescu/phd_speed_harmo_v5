#!/bin/bash
# Per-seed re-evaluation of run 4b from frozen code 11b3ebc; no new seeds.
cd /home/catalin/work/phd/v5b1_runs/b_train/code_11b3ebc
export PYTHONPATH=/home/catalin/work/phd/v5b1_runs/b_train/code_11b3ebc OMP_NUM_THREADS=1
unset SUMO_HOME
exec /home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python /home/catalin/work/phd/v5b1_runs/b_train/run4b_perseed.py
