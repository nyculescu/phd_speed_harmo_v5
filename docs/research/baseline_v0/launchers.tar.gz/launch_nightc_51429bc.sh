#!/bin/bash
# V286: per-vehicle rules (tuning, validation), then C training (3 learners x 3 envs); frozen code 51429bc; 9 workers.
set -e
cd /home/catalin/work/phd/v5b1_runs/b_train/code_51429bc
export PYTHONPATH=/home/catalin/work/phd/v5b1_runs/b_train/code_51429bc OMP_NUM_THREADS=1
unset SUMO_HOME
P="/home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet"
$P.b_train matrix --out /home/catalin/work/phd/v5b1_runs/b_train/night/c/tune --spec /home/catalin/work/phd/v5b1_runs/b_train/night/c/tune_spec.json --workers 9
$P.b_train matrix --out /home/catalin/work/phd/v5b1_runs/b_train/night/c/valp --spec /home/catalin/work/phd/v5b1_runs/b_train/night/c/valp_spec.json --workers 9
pids=()
for L in 0 1 2; do
  $P.c_train train --out /home/catalin/work/phd/v5b1_runs/b_train/night/c/train --learner $L --updates 380 --n-envs 3 &
  pids+=($!)
done
for p in "${pids[@]}"; do wait $p; done
