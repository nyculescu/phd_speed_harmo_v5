#!/bin/bash
# V278 run 4b from frozen code 11b3ebc: fixed zone opponents alongside 3 learners x 6 envs, then validation with and without delay.
cd /home/catalin/work/phd/v5b1_runs/b_train/code_11b3ebc
export PYTHONPATH=/home/catalin/work/phd/v5b1_runs/b_train/code_11b3ebc OMP_NUM_THREADS=1
unset SUMO_HOME
pids=()
/home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet.b_train zones --cfg 6 --out /home/catalin/work/phd/v5b1_runs/b_train/run4b --seeds 20 --workers 9 &
pids+=($!)
for L in 0 1 2; do
  /home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet.b_train train --cfg 6 --out /home/catalin/work/phd/v5b1_runs/b_train/run4b --learner $L --updates 500 --n-envs 6 &
  pids+=($!)
done
rc=0
for p in "${pids[@]}"; do wait $p || rc=1; done
[ $rc -eq 0 ] || exit 1
for L in 0 1 2; do
  /home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet.b_train eval --cfg 6 --out /home/catalin/work/phd/v5b1_runs/b_train/run4b --model /home/catalin/work/phd/v5b1_runs/b_train/run4b/L${L}_final --seeds 20 --workers 27 || exit 1
  /home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet.b_train eval --cfg 6 --asl 0.5 --out /home/catalin/work/phd/v5b1_runs/b_train/run4b --model /home/catalin/work/phd/v5b1_runs/b_train/run4b/L${L}_final --seeds 20 --workers 27 || exit 1
done
