#!/bin/bash
# V269 run 3, first learner from frozen code 47076bb, alongside run 2.
cd /home/catalin/work/phd/v5b1_runs/b_train/code_47076bb
export PYTHONPATH=/home/catalin/work/phd/v5b1_runs/b_train/code_47076bb OMP_NUM_THREADS=1
unset SUMO_HOME
/home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet.b_train train --cfg 3 --out /home/catalin/work/phd/v5b1_runs/b_train/run3 --learner 0 --updates 500 --n-envs 6
