#!/bin/bash
# V266 constant-cap sweep from frozen code ae7b191: 5 offsets on all slots against no control.
cd /home/catalin/work/phd/v5b1_runs/b_train/code_ae7b191
export PYTHONPATH=/home/catalin/work/phd/v5b1_runs/b_train/code_ae7b191 OMP_NUM_THREADS=1
unset SUMO_HOME
/home/catalin/work/phd/phd_speed_harmo_v5b1_toolchain/venv/bin/python -m v5b.fleet.b_train sweep --out /home/catalin/work/phd/v5b1_runs/b_train/sweep1 --seeds 20 --workers 24
